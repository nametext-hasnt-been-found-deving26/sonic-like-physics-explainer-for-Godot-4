extends CharacterBody2D


var SPEED = 900.0
var JUMP_VELOCITY = -500.0
var accel = 10
var angle = 0
var angler_dir = 0
var fixed_angle = 0
var can_downroll = false
var downrolling = false
var store_y = 0
# Get the gravity from the project settings to be synced with RigidBody nodes.
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
@onready var fallingmomentum_timer = $fallingmomentumTimer


func _physics_process(delta):
	var direction = Input.get_axis("left", "right")
	if is_on_floor():
		velocity.y = 0
		angle = get_floor_angle() 
		if angle != 0 :
			fixed_angle = angle * (180 / 3.141592)
		if angler_dir == -1 and velocity.x >= 0 and (angle * (180 / 3.141592)) >= 51:
			velocity.y = (angle  * velocity.x ) * -1
		elif angler_dir == 1 and velocity.x <= 0 and (angle * (180 / 3.141592)) >= 51 :
			velocity.y = angle  * velocity.x 
		if angler_dir != 0 and Input.is_action_pressed("jump") == false :
			floor_snap_length = 100
		else:
			floor_snap_length = 1

	# Add the gravity.
	if not is_on_floor():
		angle = 0
		floor_snap_length = 1
		velocity.y += gravity * delta
		if velocity.y > 0:
			store_y = velocity.y
			can_downroll = true
			downrolling = true
	# Handle jump.
	if Input.is_action_pressed("jump") and is_on_floor()  :
			if angle == 0:
				velocity.y = JUMP_VELOCITY
			else:
				if angler_dir == -1:
					if velocity.x >= 1:
						velocity.y = JUMP_VELOCITY - ((velocity.x/13) * (angle*8.5))
						velocity.x = move_toward(velocity.x - (fixed_angle * 16) + (angle * angler_dir * 40), SPEED * direction, accel)
					elif velocity.x <= 0:
						velocity.y = JUMP_VELOCITY + (angle * 10)
						velocity.x = move_toward(velocity.x - (fixed_angle * 12) + (angle * angler_dir * 40), SPEED * direction, accel)
				elif angler_dir == 1:
					if velocity.x <= -1:
						velocity.y = JUMP_VELOCITY + ((velocity.x/13) * (angle*8.5))
						velocity.x = move_toward(velocity.x + (fixed_angle * 16) + (angle * angler_dir * 40), SPEED * direction, accel)
						#print(velocity.x)
					elif velocity.x >= 0:
						velocity.y = JUMP_VELOCITY + (angle * 10)
						velocity.x = move_toward(velocity.x + (fixed_angle * 12) + (angle * angler_dir * 40), SPEED * direction, accel)

	if downrolling == true and is_on_floor():
		#print("true")
		fallingmomentum_timer.start()
		downrolling = false
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	if is_on_floor() and can_downroll == true and angler_dir != 0:
			velocity.x = move_toward(velocity.x + ((angle + (store_y/54)) * angler_dir * (180 / 3.141592)/4.8), SPEED * direction, accel)
			velocity.y += (gravity * delta) * (angle * (180 / 3.141592))
	
	velocity.x = move_toward(velocity.x + (angle * angler_dir * 30), SPEED  * direction, accel)
	SPEED = SPEED + (angle * (180 / 3.141592))/2 if velocity.x >= 900 or velocity.x <= -900 else 900
	#else:
		#velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()


func _on_fallingmomentum_timer_timeout():
	can_downroll = false
